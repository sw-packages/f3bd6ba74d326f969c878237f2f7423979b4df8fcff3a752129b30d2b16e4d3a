=pod

$VERSION = 1;

=cut

package InPod;

$VERSION = 2;

1;
